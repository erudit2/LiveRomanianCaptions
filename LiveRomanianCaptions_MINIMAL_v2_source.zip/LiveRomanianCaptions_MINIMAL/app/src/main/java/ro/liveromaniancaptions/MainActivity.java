package ro.liveromaniancaptions;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int CAPTURE = 7001;
    private static final int AUDIO_PERMISSION = 7002;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(36, 42, 36, 36);

        TextView title = new TextView(this);
        title.setText("Live Romanian Captions");
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER_HORIZONTAL);

        status = new TextView(this);
        status.setText(
                "Engleză → Română\n\n" +
                "1. Permite afișarea peste alte aplicații.\n" +
                "2. Apasă Pornește.\n" +
                "3. Acceptă captura audio.\n\n" +
                "Prima pornire descarcă modelul Vosk (~40 MB) și modelul de traducere ML Kit."
        );
        status.setTextSize(17);
        status.setPadding(0, 30, 0, 30);

        Button overlay = new Button(this);
        overlay.setText("Permite afișarea peste alte aplicații");
        overlay.setOnClickListener(v -> {
            Intent i = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });

        Button start = new Button(this);
        start.setText("Pornește subtitrarea");
        start.setOnClickListener(v -> requestCapture());

        Button stop = new Button(this);
        stop.setText("Oprește");
        stop.setOnClickListener(v ->
                stopService(new Intent(this, CaptureService.class)));

        box.addView(title);
        box.addView(status);
        box.addView(overlay);
        box.addView(start);
        box.addView(stop);
        setContentView(box);

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9001);
        }
    }

    private void requestCapture() {
        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION);
            status.setText("Permite accesul la audio, apoi apasă din nou «Pornește subtitrarea».");
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            status.setText("Mai întâi permite «afișarea peste alte aplicații».");
            return;
        }
        MediaProjectionManager mgr =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mgr.createScreenCaptureIntent(), CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, CaptureService.class);
            service.putExtra("resultCode", resultCode);
            service.putExtra("projectionData", data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
            else startService(service);
            status.setText("Activ. Deschide YouTube și pornește videoclipul.");
        } else {
            status.setText("Captura audio nu a fost autorizată.");
        }
    }
}
