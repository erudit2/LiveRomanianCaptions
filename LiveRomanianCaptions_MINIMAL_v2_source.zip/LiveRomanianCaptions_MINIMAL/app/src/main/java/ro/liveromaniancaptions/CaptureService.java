package ro.liveromaniancaptions;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.TextView;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.*;
import com.google.mlkit.nl.translate.Translation;
import org.vosk.Model;
import org.vosk.Recognizer;

import java.io.File;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class CaptureService extends Service {
    private static final int SAMPLE_RATE = 16000;

    private MediaProjection projection;
    private AudioRecord recorder;
    private Thread audioThread;
    private final AtomicBoolean running = new AtomicBoolean(false);

    private Model model;
    private Recognizer recognizer;
    private Translator translator;

    private ExecutorService work = Executors.newSingleThreadExecutor();
    private WindowManager wm;
    private TextView overlay;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createChannel();
        startForeground(17, notification("Pregătire…"));

        int resultCode = intent.getIntExtra("resultCode", -1);
        Intent data = Build.VERSION.SDK_INT >= 33
                ? intent.getParcelableExtra("projectionData", Intent.class)
                : getOldParcelable(intent, "projectionData");

        if (resultCode != Activity.RESULT_OK || data == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!Settings.canDrawOverlays(this)) {
            showOverlay("Permite afișarea peste alte aplicații.");
            stopSelf();
            return START_NOT_STICKY;
        }

        MediaProjectionManager mgr =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mgr.getMediaProjection(resultCode, data);

        showOverlay("Se pregătește…");

        work.execute(() -> {
            try {
                if (!ModelInstaller.isInstalled(this)) {
                    postText("Descarc modelul Vosk (~40 MB)…");
                    ModelInstaller.downloadAndInstall(this);
                }
                postText("Încarc recunoașterea vocală…");
                model = new Model(ModelInstaller.modelDir(this).getAbsolutePath());
                recognizer = new Recognizer(model, SAMPLE_RATE);

                TranslatorOptions opts = new TranslatorOptions.Builder()
                        .setSourceLanguage(TranslateLanguage.ENGLISH)
                        .setTargetLanguage(TranslateLanguage.ROMANIAN)
                        .build();
                translator = Translation.getClient(opts);

                postText("Descarc modelul EN→RO…");
                DownloadConditions conditions = new DownloadConditions.Builder()
                        .build();
                translator.downloadModelIfNeeded(conditions)
                        .addOnSuccessListener(v -> startAudio())
                        .addOnFailureListener(e -> {
                            postText("Nu s-a putut descărca modelul de traducere.");
                            stopSelf();
                        });
            } catch (Exception e) {
                postText("Eroare: " + e.getMessage());
                stopSelf();
            }
        });

        return START_NOT_STICKY;
    }

    private void startAudio() {
        work.execute(() -> {
            try {
                AudioPlaybackCaptureConfiguration config =
                        new AudioPlaybackCaptureConfiguration.Builder(projection)
                                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                                .build();

                AudioFormat format = new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build();

                int min = AudioRecord.getMinBufferSize(
                        SAMPLE_RATE,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT);
                int bufferSize = Math.max(min * 2, 8192);

                recorder = new AudioRecord.Builder()
                        .setAudioFormat(format)
                        .setBufferSizeInBytes(bufferSize)
                        .setAudioPlaybackCaptureConfig(config)
                        .build();

                recorder.startRecording();
                running.set(true);
                postText("Ascult YouTube…");

                short[] buffer = new short[4096];
                while (running.get()) {
                    int n = recorder.read(buffer, 0, buffer.length);
                    if (n > 0 && recognizer.acceptWaveForm(buffer, n)) {
                        String json = recognizer.getResult();
                        String text = extract(json, "text");
                        if (!text.isEmpty()) translate(text);
                    } else if (n > 0) {
                        String json = recognizer.getPartialResult();
                        String text = extract(json, "partial");
                        if (!text.isEmpty()) translate(text);
                    }
                }
            } catch (Exception e) {
                postText("Captura audio oprită: " + e.getMessage());
                stopSelf();
            }
        });
    }

    private void translate(String source) {
        if (translator == null || source.trim().isEmpty()) return;
        translator.translate(source.trim())
                .addOnSuccessListener(this, result -> postText(result))
                .addOnFailureListener(this, e -> {});
    }

    private String extract(String json, String key) {
        String marker = "\"" + key + "\"";
        int p = json.indexOf(marker);
        if (p < 0) return "";
        p = json.indexOf(':', p);
        if (p < 0) return "";
        int q1 = json.indexOf('"', p + 1);
        if (q1 < 0) return "";
        int q2 = json.indexOf('"', q1 + 1);
        if (q2 < 0) return "";
        return json.substring(q1 + 1, q2)
                .replace("\\\"", "\"")
                .replace("\\n", " ")
                .trim();
    }

    private void showOverlay(String text) {
        if (!Settings.canDrawOverlays(this)) return;
        if (overlay == null) {
            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            overlay = new TextView(this);
            overlay.setTextColor(Color.WHITE);
            overlay.setTextSize(20);
            overlay.setGravity(Gravity.CENTER);
            overlay.setPadding(20, 12, 20, 12);
            overlay.setBackgroundColor(0xB0000000);
            overlay.setMaxLines(4);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    Build.VERSION.SDK_INT >= 26
                            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.BOTTOM;
            lp.y = 110;
            wm.addView(overlay, lp);
        }
        overlay.setText(text);
    }

    private void postText(String text) {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (running.get() || overlay == null) showOverlay(text);
        });
    }

    private Notification notification(String text) {
        return new Notification.Builder(this, "capture")
                .setContentTitle("Live Romanian Captions")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build();
    }

    private void createChannel() {
        NotificationManager nm =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(
                "capture", "Subtitrare live", NotificationManager.IMPORTANCE_LOW));
    }

    @SuppressWarnings("deprecation")
    private Intent getOldParcelable(Intent i, String key) {
        return i.getParcelableExtra(key);
    }

    @Override
    public void onDestroy() {
        running.set(false);
        try { if (recorder != null) recorder.stop(); } catch (Exception ignored) {}
        if (recorder != null) recorder.release();
        recorder = null;
        if (projection != null) projection.stop();
        projection = null;
        if (recognizer != null) recognizer.close();
        if (model != null) model.close();
        if (translator != null) translator.close();
        work.shutdownNow();

        if (overlay != null && wm != null) {
            try { wm.removeView(overlay); } catch (Exception ignored) {}
        }
        overlay = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
