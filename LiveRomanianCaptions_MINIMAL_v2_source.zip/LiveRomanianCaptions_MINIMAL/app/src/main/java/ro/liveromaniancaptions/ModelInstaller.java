package ro.liveromaniancaptions;

import android.content.Context;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class ModelInstaller {
    private static final String MODEL_URL =
            "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip";

    private ModelInstaller() {}

    public static File modelDir(Context context) {
        return new File(context.getFilesDir(), "vosk-model-small-en-us-0.15");
    }

    public static boolean isInstalled(Context context) {
        File d = modelDir(context);
        return new File(d, "am/final.mdl").exists()
                && new File(d, "conf/model.conf").exists()
                && new File(d, "graph/HCLG.fst").exists();
    }

    public static void downloadAndInstall(Context context) throws Exception {
        File zip = new File(context.getCacheDir(), "vosk-en.zip");
        HttpURLConnection c = (HttpURLConnection) new URL(MODEL_URL).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(true);
        c.connect();
        if (c.getResponseCode() / 100 != 2) {
            throw new IOException("HTTP " + c.getResponseCode());
        }

        try (InputStream in = new BufferedInputStream(c.getInputStream());
             OutputStream out = new BufferedOutputStream(new FileOutputStream(zip))) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        } finally {
            c.disconnect();
        }

        File staging = new File(context.getFilesDir(), "vosk-staging");
        deleteRecursive(staging);
        staging.mkdirs();

        try (ZipInputStream zin = new ZipInputStream(
                new BufferedInputStream(new FileInputStream(zip)))) {
            ZipEntry e;
            byte[] buf = new byte[8192];
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName().replace('\\', '/');
                if (name.contains("..") || name.startsWith("/")) {
                    throw new IOException("Invalid archive entry");
                }
                File out = new File(staging, name);
                if (e.isDirectory()) {
                    out.mkdirs();
                } else {
                    File parent = out.getParentFile();
                    if (parent != null) parent.mkdirs();
                    try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out))) {
                        int n;
                        while ((n = zin.read(buf)) != -1) os.write(buf, 0, n);
                    }
                }
                zin.closeEntry();
            }
        }

        File extracted = new File(staging, "vosk-model-small-en-us-0.15");
        if (!new File(extracted, "am/final.mdl").exists()) {
            throw new IOException("Model incomplet");
        }

        File target = modelDir(context);
        deleteRecursive(target);
        if (!extracted.renameTo(target)) {
            copyRecursive(extracted, target);
        }
        zip.delete();
        deleteRecursive(staging);
    }

    private static void copyRecursive(File src, File dst) throws IOException {
        if (src.isDirectory()) {
            dst.mkdirs();
            File[] children = src.listFiles();
            if (children != null) for (File f : children)
                copyRecursive(f, new File(dst, f.getName()));
        } else {
            try (InputStream in = new FileInputStream(src);
                 OutputStream out = new FileOutputStream(dst)) {
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) != -1) out.write(b, 0, n);
            }
        }
    }

    private static void deleteRecursive(File f) {
        if (!f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File c : children) deleteRecursive(c);
        }
        f.delete();
    }
}
