# Live Romanian Captions — MINIMAL

Scop:
YouTube audio -> Android AudioPlaybackCapture -> Vosk English -> Google ML Kit English->Romanian -> floating overlay.

Aceasta este o bază minimală inspirată de arhitectura SUBRIMA, fără Whisper, Silero sau module native experimentale.

## Important

Acest proiect este pregătit pentru compilare, dar **nu a fost compilat în mediul curent**, deoarece mediul de lucru nu are Android SDK/Gradle instalate. Nu este prezentat ca APK testat.

## Componente

- compileSdk/targetSdk 36
- minSdk 29
- Vosk Android 0.3.75
- JNA 5.18.1
- Google ML Kit Translation 17.0.3
- model Vosk `vosk-model-small-en-us-0.15` (~40 MB), descărcat de la domeniul oficial alphacephei.com la prima pornire
- traducere EN -> RO, model ML Kit descărcat la prima pornire

## Corecție v2

`RECORD_AUDIO` este declarat și solicitat la runtime înainte de captură.

## Test pe telefon

1. Instalează APK-ul numai după ce proiectul a fost compilat într-un mediu Android de încredere.
2. Deschide aplicația.
3. Permite „afișarea peste alte aplicații”.
4. Apasă „Pornește subtitrarea”.
5. Acceptă captura audio Android.
6. Deschide YouTube și pornește un videoclip în engleză.
7. Textul românesc apare jos, peste YouTube.

## Limitări reale

- Unele aplicații pot bloca AudioPlaybackCapture prin politica lor audio; Android permite aplicației sursă să împiedice capturarea.
- Vosk small este orientat spre mobil și consumă mai puțină memorie decât modelele mari, dar acuratețea poate fi mai slabă la accente, muzică și zgomot.
- Prima instalare necesită internet pentru modelele Vosk și ML Kit. După descărcare, recunoașterea Vosk și traducerea ML Kit sunt locale.
- Traducerea este fixată pe engleză -> română pentru a reduce consumul și complexitatea.

## Surse

- Vosk: https://github.com/alphacephei/vosk-api
- Modele Vosk: https://alphacephei.com/vosk/models
- ML Kit Translation: https://developers.google.com/ml-kit/language/translation/android
- Arhitectură de referință SUBRIMA: https://github.com/y-haviv/android-subtitle-overlay
